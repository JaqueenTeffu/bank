
**LOGIN DETAILS** 

Manager
Username:   sakhile@gmail.com
Passwored:  manager123

Cashier
Username :cashier@gmail.com
Password :cashier123

User
Username: jaquar@gmail.com
Password: jaquar123
